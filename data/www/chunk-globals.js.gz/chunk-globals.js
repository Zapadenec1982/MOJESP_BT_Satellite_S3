const o="undefined"!=typeof window?window:"undefined"!=typeof globalThis?globalThis:global;export{o as g};
